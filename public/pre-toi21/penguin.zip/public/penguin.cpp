#include <utility>
#include <vector>

#include "penguin.h"

std::vector<std::pair<int, int>> find_couples(int n) {
  ask(0, 0, 0, 0);
  return std::vector<std::pair<int, int>>();
}